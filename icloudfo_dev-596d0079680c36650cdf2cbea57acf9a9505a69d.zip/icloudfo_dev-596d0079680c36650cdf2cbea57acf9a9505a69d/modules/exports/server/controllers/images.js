exports.visit = '<a href="http://www.focusonintervention.com/"><img width="140" height="39" title="" alt="" src="https://s3-us-west-1.amazonaws.com/production-foi/images-for-emails/visit.png" /></a>';
exports.submit = '<a href="http://www.focusonintervention.com/form.html"><img width="140" height="39" title="" alt="" src="https://s3-us-west-1.amazonaws.com/production-foi/images-for-emails/submit.jpg" /></a>';
exports.logo = '<a href="http://www.focusonintervention.com/"><img width="300" title="" alt="" src="https://s3-us-west-1.amazonaws.com/production-foi/images-for-emails/logo.jpg" /></a>';
