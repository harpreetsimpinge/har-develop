'use strict';
// Configuring the Calendar module
angular.module('export',['ngDialog','ui.mask','ui.calendar','ngMaterial']).run(['Menus',

]);



